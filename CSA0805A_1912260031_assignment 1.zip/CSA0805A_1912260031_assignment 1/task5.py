try:
    litres = float(input("Enter litres: "))
    fat = float(input("Enter fat percentage: "))
    snf = float(input("Enter SNF percentage: "))

    if litres <= 0:
        print("Invalid quantity")
    elif not 2.0 <= fat <= 7.0:
        print("Invalid fat percentage")
    elif snf < 0:
        print("Invalid SNF percentage")
    else:
        print(f"Litres: {litres:8.2f}")
        print(f"Fat: {fat:8.2f}")
        print(f"SNF: {snf:8.2f}")

except ValueError:
    print("Please enter valid numbers")