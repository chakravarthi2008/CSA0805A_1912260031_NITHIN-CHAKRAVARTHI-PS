from decimal import Decimal, ROUND_HALF_UP

def calculate_payment(litres, fat, snf, season, ten_day_litres):
    if season == "apr_jun":
        base = Decimal("32.00");fat_value = Decimal("0.45")
    else:
        base = Decimal("30.00");fat_value = Decimal("0.40")

    snf_value = Decimal("0.30");step = Decimal("0.1")
    fat_steps = ((fat - Decimal("3.5")) / step).quantize(Decimal("1"), rounding=ROUND_HALF_UP)
    snf_steps = ((snf - Decimal("8.5")) / step).quantize(Decimal("1"), rounding=ROUND_HALF_UP)
    rate = base + fat_steps * fat_value + snf_steps * snf_value
    amount = litres * rate

    if ten_day_litres > Decimal("500"):
        amount += litres * Decimal("0.50")
    return amount.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
# Example
litres = Decimal("20")
fat = Decimal("4.25")
snf = Decimal("8.55")
ten_day_litres = Decimal("520")
payment = calculate_payment(litres, fat, snf, "apr_jun", ten_day_litres)
print("Total payment: Rs.", payment)