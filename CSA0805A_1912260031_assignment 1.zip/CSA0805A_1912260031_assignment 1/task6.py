BASE_RATE = 30.00;FAT_STEP_VALUE = 0.40;SNF_STEP_VALUE = 0.30

def rate_per_litre(fat, snf):
    """Calculate the rate per litre."""
    fat_steps = round((fat - 3.5) / 0.1)
    snf_steps = round((snf - 8.5) / 0.1)

    rate = BASE_RATE + fat_steps * FAT_STEP_VALUE
    rate += snf_steps * SNF_STEP_VALUE

    return round(rate, 2)

def payout(litres, fat, snf):
    """Calculate the delivery payment."""
    return round(litres * rate_per_litre(fat, snf), 2)

litres = float(input("Enter litres: "))
fat = float(input("Enter fat percentage: "))
snf = float(input("Enter SNF percentage: "))

print("Rate:", rate_per_litre(fat, snf))
print("Payment:", payout(litres, fat, snf))