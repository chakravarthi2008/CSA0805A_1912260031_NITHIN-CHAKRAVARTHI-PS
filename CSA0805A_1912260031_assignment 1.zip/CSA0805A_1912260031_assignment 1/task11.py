from decimal import Decimal, ROUND_HALF_UP

BASE_RATE = Decimal("30.00")
FAT_STEP_VALUE = Decimal("0.40")
SNF_STEP_VALUE = Decimal("0.30")

def rate_per_litre(fat, snf):
    fat_steps = ((fat - Decimal("3.5")) / Decimal("0.1"))
    snf_steps = ((snf - Decimal("8.5")) / Decimal("0.1"))

    fat_steps = fat_steps.quantize(
        Decimal("1"), rounding=ROUND_HALF_UP)
    snf_steps = snf_steps.quantize(
        Decimal("1"), rounding=ROUND_HALF_UP)

    rate = BASE_RATE + fat_steps * FAT_STEP_VALUE
    rate += snf_steps * SNF_STEP_VALUE

    return rate.quantize(Decimal("0.01"))

def payout(litres, fat, snf):
    amount = litres * rate_per_litre(fat, snf)
    return amount.quantize(
        Decimal("0.01"), rounding=ROUND_HALF_UP)

litres = Decimal(input("Enter litres: "))
fat = Decimal(input("Enter fat: "))
snf = Decimal(input("Enter SNF: "))

print("Rate:", rate_per_litre(fat, snf))
print("Payment:", payout(litres, fat, snf))