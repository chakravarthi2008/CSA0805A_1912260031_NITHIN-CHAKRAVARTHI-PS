total = 0.00

for i in range(3):
    print("Enter delivery details")

    litres = float(input("Litres: "))
    fat = float(input("Fat percentage: "))
    snf = float(input("SNF percentage: "))

    fat_steps = round((fat - 3.5) / 0.1)
    snf_steps = round((snf - 8.5) / 0.1)

    rate = 30 + fat_steps * 0.40 + snf_steps * 0.30
    amount = round(litres * rate, 2)

    total += amount

    print("Payment:", amount)

print("Total payment:", round(total, 2))