from decimal import Decimal
from time import perf_counter

for n in (300, 6000, 150000):
    payments = ["33.40"] * n

    start = perf_counter()
    float_total = sum(float(x) for x in payments)
    float_time = perf_counter() - start

    start = perf_counter()
    decimal_total = sum(
        (Decimal(x) for x in payments),
        Decimal("0.00")
    )
    decimal_time = perf_counter() - start

    print("\nPayments:", n)
    print("Float total:", float_total)
    print("Decimal total:", decimal_total)
    print("Float time:", float_time)
    print("Decimal time:", decimal_time)