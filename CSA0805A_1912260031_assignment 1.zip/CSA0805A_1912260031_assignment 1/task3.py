BASE_RATE = 30.00
FAT_STEP_VALUE = 0.40
SNF_STEP_VALUE = 0.30
REFERENCE_FAT = 3.5
REFERENCE_SNF = 8.5
STEP_SIZE = 0.1

print("Base rate:", BASE_RATE)
print("Fat step value:", FAT_STEP_VALUE)
print("SNF step value:", SNF_STEP_VALUE)

a = 10
b = 20
a, b = b, a

print("After swapping:", a, b)