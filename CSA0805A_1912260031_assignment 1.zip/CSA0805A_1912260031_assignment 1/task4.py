fat = float(input("Enter the fat percentage of the milk: "))
snf = float(input("Enter the SNF percentage of the milk: "))
fat_steps = round((fat - 3.5) / 0.1)
snf_steps = round((snf - 8.5) / 0.1)

rate = 30.00 + fat_steps * 0.40 + snf_steps * 0.30

print("Fat steps:", fat_steps)
print("SNF steps:", snf_steps)
print("Rate per litre: Rs.", round(rate, 2))