def rate_per_litre(fat, snf):
    fat_steps = round((fat - 3.5) / 0.1)
    snf_steps = round((snf - 8.5) / 0.1)

    return round(30 + fat_steps * 0.40
                 + snf_steps * 0.30, 2)

def payout(litres, fat, snf):
    if litres <= 0 or not 2.0 <= fat <= 7.0 or snf < 0:
        raise ValueError("Invalid input")

    return round(litres * rate_per_litre(fat, snf), 2)
# Test Cases
assert payout(10, 3.5, 8.5) == 300.00;assert payout(8.5, 4.2, 8.7) == 283.90;assert payout(12, 3.1, 8.3) == 333.60

try:
    payout(-5, 3.5, 8.5)
except ValueError:
    print("Negative quantity rejected")

print("All payment tests passed")