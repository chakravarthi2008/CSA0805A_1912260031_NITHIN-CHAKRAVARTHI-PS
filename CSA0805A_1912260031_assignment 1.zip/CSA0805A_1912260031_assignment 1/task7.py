BASE_RATE = 30.00;FAT_STEP_VALUE = 0.40;SNF_STEP_VALUE = 0.30

def rate_per_litre(fat, snf):
    fat_steps = round((fat - 3.5) / 0.1)
    snf_steps = round((snf - 8.5) / 0.1)

    return round(
        BASE_RATE
        + fat_steps * FAT_STEP_VALUE
        + snf_steps * SNF_STEP_VALUE, 2
    )

def payout(litres, fat, snf):
    return round(litres * rate_per_litre(fat, snf), 2)

if __name__ == "__main__":
    print("Rate:", rate_per_litre(4.2, 8.7))
    print("Payment:", payout(8.5, 4.2, 8.7))