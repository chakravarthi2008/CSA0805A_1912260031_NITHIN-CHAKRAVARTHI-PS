def ways(n):
    if n <= 1:
        return 1

    return ways(n - 1) + ways(n - 2)


for n in range(1, 7):
    print(n, ways(n))