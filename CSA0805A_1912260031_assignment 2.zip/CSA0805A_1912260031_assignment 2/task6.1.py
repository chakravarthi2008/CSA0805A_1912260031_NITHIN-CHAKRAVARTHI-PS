def ways_loop(n):
    if n <= 1:
        return 1

    a = 1
    b = 1

    for i in range(2, n + 1):
        a, b = b, a + b

    return b


print("Ways for 5 steps:", ways_loop(5))
print("Ways for 1000 steps:", ways_loop(1000))