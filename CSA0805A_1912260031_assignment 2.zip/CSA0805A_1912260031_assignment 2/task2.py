correct_otp = "1234"
attempts = 0

while attempts < 3:
    otp = input("Enter OTP: ").strip()

    if otp == "":
        print("Blank entry ignored")
        continue

    attempts += 1

    if otp == correct_otp:
        print("OTP verified")
        break
    else:
        print("Incorrect OTP")
else:
    print("Account locked for 30 minutes")