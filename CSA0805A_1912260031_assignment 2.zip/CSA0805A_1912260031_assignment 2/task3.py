def normalise(text):
    return text.replace(" ", "").replace("-", "").upper()


def validate(reg):
    if len(reg) not in (9, 10):
        return False

    if not reg[:2].isalpha():
        return False

    if not reg[2:4].isdigit():
        return False

    series = reg[4:-4]

    if len(series) not in (1, 2) or not series.isalpha():
        return False

    if not reg[-4:].isdigit():
        return False

    return True


reg = input("Enter registration number: ")
reg = normalise(reg)

if validate(reg):
    print("Valid registration number")
    print(reg[:2], reg[2:4], reg[4:-4], reg[-4:])
else:
    print("Invalid registration number")