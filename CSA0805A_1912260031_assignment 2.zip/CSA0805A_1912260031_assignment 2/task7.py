def ways_original(n):
    if n <= 1:
        return 1

    return ways_original(n - 1) + ways_original(n - 2)


def ways_redesigned(n):
    if n <= 1:
        return 1

    previous = 1
    current = 1

    for i in range(2, n + 1):
        previous, current = current, previous + current

    return current


for n in [10, 20, 25, 30, 1000]:
    print("Steps:", n)
    print("Redesigned answer:", ways_redesigned(n))