def subsidy(units, ration_card, elderly):
    if units <= 100:
        return "Full subsidy"
    elif units <= 200 and ration_card:
        return "Partial subsidy"
    elif units > 200 and elderly:
        return "Special subsidy"
    else:
        return "No subsidy"


print(subsidy(100, False, False))
print(subsidy(150, True, False))
print(subsidy(250, False, True))
print(subsidy(150, False, False))